#Advanced data manipulation
library(dplyr)
library(ggplot2)
data(diamonds)
head(diamonds)
filter(diamonds,carat>4,cut=="Premium",price>5000,x>7,y>7,z>4)
slice(diamonds,6:10)#extracts the sixth to tenth rows of the data set
arrange(diamonds,carat,cut,color)#order as per values in specified columns
arrange(diamonds,desc(carat))#order according to specific column
select(diamonds,carat,price)#extracts the carat and price column
select(diamonds,x:z)#extracts columns from x to z
select(diamonds,-(x:z))#extracts all columns except x to z
#Helper functions
select(diamonds,starts_with("c"),contains("t"))#Extracts rows whose row names start with c or have t
#Renaming columns
rename(diamonds,cut_grade=cut)
#Extracting unique values 
distinct(select(diamonds,carat,cut))#specific values of carat with specific values of cut
#Adding new columns
mutate(diamonds,multiply=x*y)#Hypothetical volume
#This creates columns that are as a result of functions of other columns
#Keeping just the new column
transmute(diamonds,multiply=x*y)#Retaining just the hypothetical volume column
summarise(diamonds,deviation=sd(carat),average=mean(depth),midpoint=median(price))#Summarises the data set into one row depending on the function performed on a column 
#Sampling rows
sample_n(diamonds,10)#Randomly selects 20 rows of data
sample_frac(diamonds,0.00018)#Randomly selects 0.0005 proportion of rows of data

##Grouped functions
#The functions become really powerful especially when using diverse combinations.
#Chaining is the process of wrapping functions inside the other. 
summarise(
  filter(
    sample_n(
      select(diamonds,contains("t"),price),
    500),
  carat<2.5),
deviation=sd(carat),average=mean(depth),midpoint=median(price))
#The functions are executed from the innermost operation outwards. 

#Advanced indexing syntax
#Vectors
vec<-rnorm(50,6,8)
vec[2]
vec[[2]]
vec[2.6]
vec[58]
vec[-25:-50]
vec[0]
vec[]
vec[NA]
#Matrices and Arrays
mat<-matrix(1:60,nrow=10)
mat[5,2]
mat[6]
ind<-c(2,6,1,5,3,4,5,6)
example<-matrix(ind,nrow=4,byrow=TRUE)
mat[example]
is.vector(mat[example])
mat[0]
mat[NA]
mat[-5]
mat[TRUE]
mat[5,]
mat[,4]
#Other structures
x<-1:50
lst<-lm(vec~x)
is.list(lst)
lst$"coefficients"
lst[[1]]
lst[1]
#Replacing elements
mat[6:8,]<-21;mat
mat[6,2]<-NA;mat
mat[is.na(mat)]<-0;mat


#String processing
library(stringr)
#joining multiple strings into one string
new<-str_c("We","are","using","R","to","process","strings",sep=" ");new
str_join("We","are","using","R","to","process","strings",sep=" ")
#counting the matches
str_count(new,"e")
#Patterns
#detecting the presence and absence of a pattern
str_detect(new,"f")#Boolean vector
str_detect(new,"[a$]")#word starting with letter a
#locating the position of the first occurence of a pattern in the string
str_locate(new,"[a$]")
#locating the position of all occurences of a pattern in a string
str_locate_all(new,"[aeiou]")
#extracting first piece of a string that matches a pattern
str_extract(new,"[a-p]")
#extracting all pieces of a string that match a pattern
str_extract_all(new,"[a-p]")
#replace first occurence of a matched pattern in a string
str_replace(new,"[a-p]","$")
#replace all occurences of a matched pattern in a string
str_replace_all(new,"[a-p]","$")
#number of characters in the string
str_length(new)
#extract first matched group from a string
str_match(new,"s")
#extract all matched groups from a string
str_match_all(new,"s")
#extracts substrings from a character vector
str_sub(new,start=8,end=12)
#replace substrings in a character vector. Recycles all arguments to be the same length as the longest argument
str_sub(new,start=4,end=12)<-"used";new 
#duplicates strings
str_dup(new,times=2)
#pads a string
str_pad(new,width=40,side="both",pad=" ")
#removes whitespace at the beginning and end of string
str_trim(new,side="both")
#wraps a string into a formatted paragraph
cat(str_wrap(new,width=12,exdent=2))
#split up a string into a variable number of pieces
str_split(new,pattern=" ",n=Inf)
#split up a string into a fixed number of pieces
str_split_fixed(new,pattern=" ",n=4)


#Date Processing
library(lubridate)
ymd("20150409")
dmy("09042015")
mdy("04092015")
#Parse functions
dmy_hms("09-04-2015 15:00:00",tz="GMT")
a<-dmy_hms("09-04-2015 15:00:00",tz="GMT")
hour(a)<-16;a#Changes the hour to 16
wday(a,label=TRUE)#returns day of the week
yday(a)#Day of the year
mday(a)#Day of the month
with_tz(a,"Pacific/Auckland")#Displays the current time at another time zone
force_tz(a,"America/Chicago")#Changes the time zone in the object
b<-dmy_hms("15-04-2015 15:00:00",tz="GMT")
c<-interval(a,b);c#Showing the interval between two times
d<-dmy_hms("06-05-2015 17:00:00",tz="GMT")
e<-interval(b,d)
setdiff(c,e)#Checking for overlapping intervals
int_start(c)#When the interval starts
int_end(c)#When the interval ends
int_flip(c)#Reverse the direction of the interval
int_shift(c,new_duration(days=6))#alter the interval start or end
int_aligns(c,e)#Tests the alignment of the start or end of two intervals
int_length(c)#Gets the length of the interval in seconds
intersect()
union()
e%within%c #Checks if one interval is within another
hours(3)
dhours(3)
ehours(3)#Exact years
leap_year(2016)#Logical output
dmy(09042015)+years(2)#The same date
dmy(09042015)+eyears(2)#Adds 365 days
a+days(7)#Adds a number of days to the date
a+months(2:6)#Adds the consecutive number of months to the date
c%/%days(2)
c/edays(3)
c/dminutes(1)
c%%minutes(2)
as.period(c%%years(2))
as.period(c)
d<-dmy("31012015")
d+months(0:30)
floor_date(d,"month")+months(0:11)+days(31)
d%m+%months(0:11)
last_day <- function(date) {
  ceiling_date(date, "month") - days(1)
}
last_day(a)

#SQL in R
#Allows SQL selects to be performed on data frames in R
library(sqldf)
sqldf("select * from diamonds where carat between 4.0 and 5.0")
sqldf("select * from diamonds where cut like 'Fair'")
#descending
sqldf("select * from diamonds order by carat desc limit 6")
#ascending
sqldf("select * from diamonds order by carat limit 10")
sqldf("select * from diamonds where carat>3.2 and cut='Premium'")
#summarising dataframe with price average of each carat 
sqldf("select carat, avg(price) as avg_price from diamonds group by carat")

#Data Processing and Transformation
library(reshape2)
#Melting
#Into a data frame

example1<-melt(diamonds,id=c("cut","color","clarity"))
head(example1)
#Casting functions
dcast(example1,cut~variable,mean)
#Melting and casting
example3<-recast(diamonds,cut~variable,id.var=2)
example3


#Efficient data processing and transformation
library(tidyr)
object<-sample_n(diamonds,50)
example4<-gather(object,key=new.column,value=carat,carat,cut,color,clarity)
head(example4,10)
example5<-spread(example4,new.column,carat)
head(example5,15)

#Speeding up in R
#Parallelisation
library(parallel)
core.no<-detectCores()
core.no
new.cluster<-makeCluster(core.no)
new.cluster
mat
parRapply(new.cluster,mat,mean)
stopCluster(new.cluster)
#Using a loop
#Random Number Generation
library(doParallel)
#Nonparallel
start<-Sys.time()
object2<-foreach(i=1:1000) %do% {
  object3<-runif(1000,40,6000)
  object4<-summary(object3)
  object4
}
print(Sys.time()-start)
#Parallel
another.cluster<-makeCluster(0.2)
registerDoParallel(another.cluster)
strt<-Sys.time()
object2<-foreach(i=1:1000) %dopar% {
  object3<-runif(1000,40,6000)
  object4<-summary(object3)
  object4
}
print(Sys.time()-strt)
stopCluster(another.cluster)

#Nonparallel
start<-Sys.time()
object2<-foreach(i=1:10000) %do% {
  object3<-runif(10000,40,6000)
  object4<-summary(object3)
  object4
}
print(Sys.time()-start)
#Parallel
another.cluster<-makeCluster(0.2)
registerDoParallel(another.cluster)
strt<-Sys.time()
object2<-foreach(i=1:100000) %dopar% {
  object3<-runif(100000,40,6000)
  object4<-summary(object3)
  object4
}
print(Sys.time()-strt)
stopCluster(another.cluster)


#Inline C++ code
library(Rcpp)
library(inline)
#Example of simple C++ code

#Writing C++ functions in R
code1<-cppFunction('
  int mean(int a,int b){
    int quick=(a+b)/2;
    return quick;
  }'
)
code1(4569,84542)

#Sourcing C++ code

sourceCpp("C++.cpp")
giveOutput(c(4,6,8))


#Extending R's memory
#Working with massive objects in secondary memory
#the big family of packages
library(bigmemory.sri)
attach.resource()
describe(diamonds)

#Object-oriented programming in R
#S3 and S4 classes
#S3
p<-list(name="Mark",education="Degree",graduated=TRUE)
class(p)<-"school"
attributes(p)

print.school<- function(learning) {
  cat(learning$name,"\n")
  cat("education",learning$education,"\n")
  cat("graduated",learning$graduated,"\n")
}
p

g<-list(name="Pauline",education="Masters",graduated=FALSE,fee.balance=5100)
class(g)<-c("cleared","school")
g

#S4
setClass("school",representation(
  name="character",education="character",graduated="logical",fee.balance="numeric"
  )
)
h<-new("school",name="Beaty",education="PhD",graduated=FALSE,fee.balance=600)
h
t<-new("school",name="Pauline",education="Masters",graduated=FALSE,fee.balance=5100);t
h@name
slot(h,"name")
h@graduated<-TRUE
slot(h,"fee.balance")<-0
h

setMethod("show", "school",
    function(object){
      inorout <- ifelse(object@graduated,"has","has not")
        cat(object@name,"has attained a",object@education,",",
          inorout,"graduated","and has a fee balance of",object@fee.balance,"\n")
    }
)
h
t
#Functional Programming
w<-rbinom(10,78,0.412);w
tracemem(w)
w[4]<-3
tracemem(w)

#Additional topics
#Using R on a server
#Using R in Batch mode

pdf("data.pdf") 
vec<-rnorm(50,6,8)
plot(vec,main="Random Numbers Under the Normal Distrubution",type="l") 
dev.off() 



#Using R on the cloud
#R and Hadoop
What is Hadoop?

