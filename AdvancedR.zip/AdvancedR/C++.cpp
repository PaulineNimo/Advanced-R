#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
NumericVector plusTwo(NumericVector x){
  NumericVector out=x+2.0;
  return out;
}

// [[Rcpp::export]]
NumericVector giveOutput(NumericVector a){
  NumericVector b=plusTwo(a);
  return b;
}
/*** R
*/
