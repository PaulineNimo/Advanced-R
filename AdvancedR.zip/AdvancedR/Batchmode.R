pdf("data.pdf") 
vec<-rnorm(50,6,8)
plot(vec,main="Random Numbers Under the Normal Distrubution",type="l") 
dev.off()